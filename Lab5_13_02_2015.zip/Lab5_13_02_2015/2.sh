read -p "Enter String:" str
if [ "$str" = `echo $str | rev` ]
then
	echo "It's Palindrome..."
else
	echo "It is not Palindrome..."
fi
