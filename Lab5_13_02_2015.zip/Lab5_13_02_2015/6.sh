if [ $1 -gt 0 ]
then
	echo `expr \( $1 \* \( $1 + 1 \) \) \/ 2`;
else
	echo `expr \( 50 \* \( 50 + 1 \) \) \/ 2`;
fi
