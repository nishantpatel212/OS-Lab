str="*"
ls $1$str
