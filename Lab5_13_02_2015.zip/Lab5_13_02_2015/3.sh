yes $2 | head -n $1
