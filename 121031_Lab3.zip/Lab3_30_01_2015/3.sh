read -p "Enter First Number : " number1
read -p "Enter Second Number : " number2

echo "1. Sum"
echo "2. Mul"
echo "3. Sub"
echo "4. Div"
echo "5. Mod"
read -p "Enter Your Choice : " choice

case $choice in
    1)
        echo "Sum : " $(($number1+$number2))
        ;;
    2)
        echo "Mul : " $(($number1*$number2))
        ;;
    3)
        echo "Sub : " $(($number1-$number2))
        ;;
    4)
        echo "Div : " $(($number1/$number2))
        ;;
    5)
        echo "Mol : " $(($number1%$number2))
        ;;
    *) echo "Invalid Choice"
    	;;
esac






