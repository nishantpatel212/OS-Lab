read -p "Enter First Number : " number1
read -p "Enter Second Number : " number2

echo "Sum : " $(($number1+$number2))
echo "Mul : " $(($number1*$number2))
echo "Sub : " $(($number1-$number2))
echo "Div : " $(($number1/$number2))
echo "Mod : " $(($number1%$number2))
