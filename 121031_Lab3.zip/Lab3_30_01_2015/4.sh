read -p "Enter First Number : " number1
read -p "Enter Second Number : " number2

if test $number1 == $number2
then
	echo "Numbers are equal"
fi

if test $number1 -gt $number2
then
	echo $number1 "is greater then" $number2
fi

if test $number1 -lt $number2
then
	echo $number1 "is less then" $number2
fi
