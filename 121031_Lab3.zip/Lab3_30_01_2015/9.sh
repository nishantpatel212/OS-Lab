read -p "Enter Capital of Gujarat : " str

while :
do
	if test $str == "Gandhinagar"
	then
		break
	fi
	
	read -p "Renter Capital of Gujarat : " str
done

echo "Answer is right"
