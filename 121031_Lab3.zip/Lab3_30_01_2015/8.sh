read -p "Enter Number : " number

f1=0
f2=1

for (( i=0;i<=number;i++ ))
do
     echo -n "$f1 "
     fn=$((f1+f2))
     f1=$f2
     f2=$fn
done

echo
