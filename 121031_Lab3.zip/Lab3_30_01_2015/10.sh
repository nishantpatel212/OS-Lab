read -p "Enter array limit : " limit

echo "Enter elements"
n=1

while [ $n -le $limit ]
do
	read arr$n
	n=`expr $n + 1`
done

echo "Enter key element"
read key

n=1

while [ $n -le $limit ]
do
	num=$((arr$n))
	if test $num == $key
	then
		echo "element found"
		break
	fi
	n=`expr $n + 1`
done
