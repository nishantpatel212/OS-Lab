read -p "Enter Word : " str
if test $str == "Jan"
then
	echo "January"
elif test $str == "Janu"
then
	echo "January"
elif test $str == "Janua"
then
	echo "January"
elif test $str == "January"
then
	echo "January"
else
	echo ""
fi
