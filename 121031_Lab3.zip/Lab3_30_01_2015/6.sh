read -p "Enter Command : " cmd
$cmd
