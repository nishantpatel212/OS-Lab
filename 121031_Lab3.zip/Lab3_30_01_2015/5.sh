read -p "Enter Number : " number
if test $number -lt 50
then
	echo "Sq : " $(($number*$number))
else
	echo "Number is greater then 50"
fi
