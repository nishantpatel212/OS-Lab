#include<stdio.h>

void main()
{
	int n;

	printf("Enter total number of processes:");
	scanf("%d",&n);
	
	int  burstTime[n], waitTime[n], turnAroundtime[n], i, j;

	for(i = 0; i < n; i++)
	{
		printf("\nEnter Burst Time for Process %d:", i+1);
		scanf("%d", &burstTime[i]);
	}

	printf("\n Process |  Burst Time  | Waiting Time  | Turnaround Time");
	printf("\n---------+--------------+---------------+----------------");
	for(i = 0; i < n; i++)
	{
		waitTime[i] = 0;
		for(j = 0; j < i; j++)
			waitTime[i] += burstTime[j];
			
		turnAroundtime[i] = burstTime[i] + waitTime[i];
		printf("\n   %d\t |\t%d\t|\t%d\t|\t%d", i+1, burstTime[i], waitTime[i], turnAroundtime[i]);
	}
	printf("\n");
}
