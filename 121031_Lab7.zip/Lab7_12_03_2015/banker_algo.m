clear all;
close all;

claim = [7 5 3;
         3 2 2;
         9 0 2;
         2 2 2;
         4 3 3;];

allocated = [0 1 0;
             2 0 0;
             3 0 2;
             2 1 1;
             0 0 2;];

available = [3 3 2;];

need = claim - allocated;

i = 1;
temp = 0;
count = 0;

s = size(claim);

while (i <= s(1))
%for i = 1 : s(1)
    for j = 1 : s(2)
        if (need(i,j) > available(1,j))
            break;
        end
        
        for k = 1 : s(2)
            if (need(i,k) > 0)
                disp(i);
                count = count + 1;
                available = available + allocated(i,:);
                allocated(i,:) = 0;
                claim(i,:) = 0;
                need(i,:) = 0;
                temp = 1;
                break;
            end
        end
        if temp == 1
            i = 0;
            temp = 0;
        end
        break;
    end
    i = i + 1;
end

if count ~= s(1)
    disp('It is Deadlock...');
end