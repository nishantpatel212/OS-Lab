read -p "Enter File Name : " fName
echo "The Number of words in $fName are:"
wc -w $fName
