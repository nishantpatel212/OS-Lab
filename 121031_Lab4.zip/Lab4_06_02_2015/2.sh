read -p "Enter Number : " str
b= grep $str test.txt;
if [ $? -eq 0 ]
	then
	echo "Word  found"
else
	echo "Not Successful"
fi
