read -p "Enter File Name : " fName
echo "The New Line in file is:"
wc -l $fName
