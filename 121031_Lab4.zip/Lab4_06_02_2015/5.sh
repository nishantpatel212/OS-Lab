read -p "Enter Employee Basic Salary : " b_sal
read -p "Enter Percentage : " per
echo "HRA : " $(($b_sal*$per/100))
