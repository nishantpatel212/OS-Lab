read -p "Enter Number : " number
chk=`factor $number|wc -w`; 
if [ $chk -eq 2 ]
then 
	echo "Number is Prime"
else 
	echo "Number is Not Prime"
fi
