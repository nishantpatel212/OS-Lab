#!/bin/bash
hr=`echo $(date +%H)`

if [ $hr -le 10 ]&&[ $hr -ge  6 ]
then
	echo "Good Morning"
elif [ $hr -gt 10 ]&&[ $hr -le 16 ]
then 
	echo "Good After Noon"
elif [ $hr -gt 16 ]&&[ $hr -le 20 ]
then 
	echo "Good Evening"
elif [ $hr -gt 20 ]
then
	echo "Good Night"
elif [ $hr -le 6 ]
then
	echo "Good Night"
fi
