loop=1
while [ $loop -eq 1 ]
do
	read -p "Enter Number : " number
	if test $number -lt 50
	then
		echo "Sq : " $(($number*$number))
	else
		echo "Number is greater then 50"
	fi
	read -p "Do you want to Continue(1/0) : " loop
done
