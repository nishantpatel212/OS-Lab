read -p "Enter File Name : " fName
n=`cut -d' ' -f 1- $fName | tr ' ' '\n' | wc -l |cut -d' ' -f1 `
echo $(( n - 1))
