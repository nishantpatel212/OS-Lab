echo "Permissioons are :"
ls -l $1
read -p "Do you want to revoke read and write conditions from the file (y/n) :" chk
if [ "$chk" = "y" ]
then 
	chmod -rw echo $1
	echo "After revoking"	
	ls -l $1
elif [ "$chk" = "n" ] 
then
	echo "No Change"
fi
