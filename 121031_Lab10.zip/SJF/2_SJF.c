#include<stdio.h>

void main()
{
	int n;

	printf("Enter total number of processes:");
	scanf("%d",&n);
	
	int  burstTime[n], waitTime[n], turnAroundtime[n], processNumber[n], i, j;
	
	int total=0,pos,temp;
    
    for(i = 0; i < n; i++)
	{
		printf("\nEnter Burst Time for Process %d:", i+1);
		scanf("%d", &burstTime[i]);
		processNumber[i] = i + 1;
	}
	
	for(i = 0; i < n; i++)
	{
		temp = burstTime[i];
		for(j = i + 1; j < n; j++)
		{
			if(burstTime[j] < temp)
			{
				burstTime[i] = burstTime[j];
				burstTime[j] = temp;
				
				temp = processNumber[i];
				processNumber[i] = processNumber[j];
				processNumber[j] = temp;
				
				temp = burstTime[i];
			}
		}
	}
	
	printf("\n Process |  Burst Time  | Waiting Time  | Turnaround Time");
	printf("\n---------+--------------+---------------+----------------");
	for(i = 0; i < n; i++)
	{
		waitTime[i] = 0;
		for(j = 0; j < i; j++)
			waitTime[i] += burstTime[j];
			
		turnAroundtime[i] = burstTime[i] + waitTime[i];
		printf("\n   %d\t |\t%d\t|\t%d\t|\t%d", processNumber[i], burstTime[i], waitTime[i], turnAroundtime[i]);
	}
	printf("\n");
}
