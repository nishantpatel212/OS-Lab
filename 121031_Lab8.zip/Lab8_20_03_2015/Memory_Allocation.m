clear all;
close all;
load trees;

% size of last swap in process is 212KB
incommingProcessSize = 100;

%white : Allocated
%black : free space
%red : last allocated
%blue : new incomming process

processes = 1;

memoryBlock(2049, 100, 3) = 0;

for i = 1 : 48
    memoryBlock(i,:,:) = 255;
end
swapInProcesses(processes, 1) = 47;
swapInProcesses(processes, 2) = 1;
swapInProcesses(processes, 3) = 48;
processes = processes + 1;

for i = 152 : 302
    memoryBlock(i,:,:) = 255;
end
swapInProcesses(processes, 1) = 150;
swapInProcesses(processes, 2) = 152;
swapInProcesses(processes, 3) = 302;
processes = processes + 1;

for i = 303 : 502
    memoryBlock(i,:,:) = 255;
end
swapInProcesses(processes, 1) = 200;
swapInProcesses(processes, 2) = 303;
swapInProcesses(processes, 3) = 502;
processes = processes + 1;

for i = 951 : 1024
    memoryBlock(i,:,:) = 255;
end
swapInProcesses(processes, 1) = 73;
swapInProcesses(processes, 2) = 951;
swapInProcesses(processes, 3) = 1024;
processes = processes + 1;

for i = 1602 : 1814
    memoryBlock(i,:,1) = 255;
end
swapInProcesses(processes, 1) = 212;
swapInProcesses(processes, 2) = 1602;
swapInProcesses(processes, 3) = 1814;
lastProcess = processes;
processes = processes + 1;

for i = 1915 : 2049
    memoryBlock(i,:,:) = 255;
end
swapInProcesses(processes, 1) = 134;
swapInProcesses(processes, 2) = 1915;
swapInProcesses(processes, 3) = 2049;
processes = processes + 1;

figure;
subplot(1,5,1);
imshow(memoryBlock);
title('Initial');

BestFit = memoryBlock;
for i = 1 : processes - 2
    freeSpaces(i) = swapInProcesses(i+1,2) - swapInProcesses(i,3) - 1;
    bestFit(i) = freeSpaces(i) - incommingProcessSize;
end
[minB, i] = min(bestFit);
while(minB < 0)
    bestFit(i) = max(bestFit) + 100;
    [minB, i] = min(bestFit);
end
[minB, j] = min(bestFit);
for i = swapInProcesses(j,3) : swapInProcesses(j,3) + incommingProcessSize
    BestFit(i,:,3) = 255;
end
subplot(1,5,2);
imshow(BestFit);
title('Best Fit');

NextFit = memoryBlock;
done = 0;
for i = lastProcess : processes - 2
    if (swapInProcesses(i+1,2) - swapInProcesses(i,3) - 1) >= incommingProcessSize
        for j = swapInProcesses(i,3) : swapInProcesses(i,3) + incommingProcessSize
            NextFit(j,:,3) = 255;
        end
        done = 1;
        break;
    end
end
if done == 0
    for i = 1 : lastProcess
        if (swapInProcesses(i+1,2) - swapInProcesses(i,3) - 1) >= incommingProcessSize
            for j = swapInProcesses(i,3) : swapInProcesses(i,3) + incommingProcessSize
                NextFit(j,:,3) = 255;
            end
            break;
        end
    end
end
subplot(1,5,3);
imshow(NextFit);
title('Next Fit');

FirstFit = memoryBlock;
for i = 1 : processes - 2
    if (swapInProcesses(i+1,2) - swapInProcesses(i,3) - 1) >= incommingProcessSize
        for j = swapInProcesses(i,3) : swapInProcesses(i,3) + incommingProcessSize
            FirstFit(j,:,3) = 255;
        end
        done = 1;
        break;
    end
end
subplot(1,5,4);
imshow(FirstFit);
title('First Fit');

WorstFit = memoryBlock;
for i = 1 : processes - 2
    freeSpaces(i) = swapInProcesses(i+1,2) - swapInProcesses(i,3) - 1;
    worstFit(i) = freeSpaces(i) - incommingProcessSize;
end
[maxW, j] = max(worstFit);
for i = swapInProcesses(j,3) : swapInProcesses(j,3) + incommingProcessSize
    WorstFit(i,:,3) = 255;
end
subplot(1,5,5);
imshow(WorstFit);
title('Worst Fit');