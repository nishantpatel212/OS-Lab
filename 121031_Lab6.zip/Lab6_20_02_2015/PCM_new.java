public class PCM_new
{
	public static void main(String [] args)
	{
		Buffer b = new Buffer(5);
		Producer p = new Producer(b);
		Consumer c = new Consumer(b);

		p.start();
		c.start();
	}
}

class Buffer 
{
	private int [] buffer;
	private int count = 0, in = 0, out = 0;

	Buffer(int size)
	{
		buffer = new int[size];
	}

	public synchronized void Put(int c) 
	{
		while(count == buffer.length) 
		{
			try 
			{ 
				wait();
			}
			
			catch (InterruptedException e) 
			{
			} 
			
			finally 
			{  
			}
			
			System.out.println("----------------------Producer----------------------"); 
		} 
		System.out.println("Produced " + c);
		buffer[in] = c; 
		in = (in + 1) % buffer.length; 
		count++; 
		notify(); 
	}

	public synchronized int Get() 
	{
		while (count == 0) 
		{
			try 
			{
				wait(); 
			}
			
			catch (InterruptedException e) 
			{ 
			} 
			
			finally 
			{ 
			}
			 
			System.out.println("----------------------Consumer----------------------");
		} 
		int c = buffer[out]; 
		out = (out + 1) % buffer.length;
		count--;
		System.out.println("Consumed " + c); 
		notify(); 
		return c;
	}
}

class Producer extends Thread 
{
	private Buffer buffer;

	Producer(Buffer b) 
	{
		buffer = b; 
	}
	
	public void run() 
	{
		System.out.println("----------------------Producer----------------------"); 
		
		for(int i = 0; i < 20;) 
			buffer.Put(++i);
	}
}    

class Consumer extends Thread 
{
	private Buffer buffer;

	Consumer(Buffer b) 
	{ 
		buffer = b; 
	}
	
	public void run() 
	{
		System.out.println("----------------------Consumer----------------------");
		
		for(int i = 0; i < 20; i++)
			buffer.Get();
	}
}   
